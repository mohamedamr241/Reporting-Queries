define( [], function()
{
    return {};
} );
